# Helpers

## Language detection

`laya.detect_language` is `laya.lang.analyse`.

::: laya.lang.analyse

::: laya.lang.detect_script

::: laya.lang.is_english

## Email

::: laya.email.clean_email_body

::: laya.email.email_state

## Question presets

::: laya.presets.triage_questions

::: laya.presets.email_questions

::: laya.presets.guard_questions

::: laya.presets.moderation_questions

::: laya.presets.router_questions

## Shortlisting

::: laya.shortlist.shortlist_choice

::: laya.shortlist.predict_shortlist

::: laya.shortlist.embed_fn_from_agent

::: laya.shortlist.cached_embed_fn

## Abstention

::: laya.confidence.check_min_confidence

::: laya.confidence.check_min_confidence_map

::: laya.confidence.resolve_min_confidence

::: laya.confidence.flag_low_confidence

::: laya.confidence.apply_confidence_gate

::: laya.confidence.GATE_STATES

## Calibration and training

::: laya.common.answer_confidence

::: laya.common.confidence_from_probs

::: laya.common.ece_score

::: laya.calibrate.fit_temperatures

::: laya.calibrate.fit_one_temperature

::: laya.calibrate.fit_temperature_map

::: laya.calibrate.fit_abstention_thresholds
::: laya.calibrate.fit_binning_map

::: laya.calibrate.apply_binning_map

::: laya.common.render_options

::: laya.common.proper_reward

::: laya.common.td_lambda_targets

::: laya.common.QTYPES

::: laya.common.QTYPE_NAMES
